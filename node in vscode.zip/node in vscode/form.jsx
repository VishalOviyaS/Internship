import React from 'react';
function App(){
    return (
        <div className="container">
            <input type="text" placeholder="Enter Your Name"/>
            <button>Submit</button>
        </div>
    );
}
export default App;