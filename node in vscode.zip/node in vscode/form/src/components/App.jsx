import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    
      <div className="container">
        <form>
        <fieldset>
          <legend>REGISTRATION FORM</legend>
            Name <input type="text" placeholder="Enter Your Name"/>
            <br></br>
            <br></br>
            Course <select>
              <option>SELECT</option>
              <option>CSE</option>
              <option>ECE</option>
              <option>IT</option>
              <option>EEE</option>
            </select>
            <br></br>
            <br></br>
            Email <input type='email' placeholder='Enter your Email'/>
            <br></br>
            <br></br>
            Age <input type="number" placeholder="Enter Your Age"/>
            <br></br>
            <br></br>
            Choose languages you know?
            <br></br>
            <input type='checkbox' name='C' value={"yes"}/>C
            <br></br>
            <input type='checkbox' name='C++' value={"yes"}/>C++
            <br></br>
            <input type='checkbox' name='Java' value={"yes"}/>Java
            <br></br>
            <input type='checkbox' name='Python' value={"yes"}/>Python
            <br></br>
            <input type='checkbox' name='JavaScript' value={"yes"}/>JavaScript
            <br></br>
            <br></br>
            Address <input type="text" placeholder="Enter Your Address"/>
            <br></br>
            <br></br>
            Mobile Number <input type='text' placeholder="Enter Your Mobile Number"/>
            <br></br>
            <br></br>
            Gender
            <br></br>
            <input type="radio" name='Gender' value={"Male"}/>Male
            <br></br>
            <input type="radio" name='Gender' value={"Female"}/>Female
             <br></br>
             <br></br>

            <button>Submit</button>
            </fieldset>
            </form>
        </div>
      
        

    </>
  )
}

export default App
